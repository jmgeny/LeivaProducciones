<section>
	<div class="panel panel-default">
		<div class="panel-heading">heading</div>
		<div class="panel-body">Panel Content</div>
		<div class="panel-footer">Panel Footer</div>
	</div>	

	<div class="panel panel-default">
		<div class="panel-heading">heading</div>
		<div class="panel-body">Panel Content</div>
		<div class="panel-footer">Panel Footer</div>
	</div>	
</section>