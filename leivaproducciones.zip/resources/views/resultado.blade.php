@extends('layouts.vistas')

@section('title','Resultado')

@section('content')


@endsection