<ul class="nav nav-pills nav-stacked">
    <li><a href="{{url('/index')}}">Inicio</a></li>
    <li><a href="{{route('editEventos.index')}}">Eventos</a></li>
    <li><a href="{{route('editCampeonatos.index')}}">Campeonatos</a></li>
</ul>