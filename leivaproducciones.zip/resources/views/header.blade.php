<header class="masthead bg-header text-white text-center">
	<div class="container">
		{{-- <img class="mb-0 d-block mx-auto" src="img/logoLeiman.png" alt=""> --}}
		<img class="mb-0 imgHeader mx-auto" src="img/logoLeiman.png" alt="">
        <h1 class="text-uppercase mb-0">Leiva Producciones</h1>
        <h2 class="font-weight-light mb-0">Organizamos todo tipo de evento deportivo</h2>
    </div>
</header>
	@include('carrusel')
