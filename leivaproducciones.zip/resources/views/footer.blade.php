    <footer class="footer text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-4 mb-5 mb-lg-0">
            {{-- <h4 class="text-uppercase mb-4">Location</h4>
            <p class="lead mb-0">2215 John Daniel Drive
              <br>Clark, MO 65243</p> --}}
          </div>
          <div class="col-md-4 mb-5 mb-lg-0">
            @include('redes')
          </div>
          <div class="col-md-4">
            {{-- <h4 class="text-uppercase mb-4">LEIMAN</h4>
            <p class="lead mb-0">
              <a href="http://startbootstrap.com">JMG</a>.</p> --}}
          </div>
        </div>
      </div>
    </footer>