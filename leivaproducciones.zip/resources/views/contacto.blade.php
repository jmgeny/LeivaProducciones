<section id="contact">
    <div class="container">
      <h3 class="text-center">Contacto</h3>
      <div class="row test">
        <div class="col-md-4">
          <p>Leiva Producciónes Deportivas</p>
          <p><span class="glyphicon glyphicon-map-marker"></span>Ezeiza, ARG</p>
          <p><span class="glyphicon glyphicon-phone"></span>Cel: +54 9 11 3346-5350</p>
          <p><span class="glyphicon glyphicon-envelope"></span>e-mail: leivaproducciones@yahoo.com.ar</p> 
        </div>
        <div class="col-md-8">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3277.772847972039!2d-58.55493678514323!3d-34.76131447336001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccf8a20fbe16d%3A0xa274f9fc4d2b1932!2sAv+de+la+Noria%2C+Ezeiza%2C+Buenos+Aires!5e0!3m2!1ses!2sar!4v1530795793469" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
{{--           <div class="row">
            <div class="col-sm-6 form-group">
              <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
            </div>
            <div class="col-sm-6 form-group">
              <input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
            </div>
          </div>
          <textarea class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea>
          <div class="row">
            <div class="col-md-12 form-group">
              <button class="btn pull-right" type="submit">Send</button>
            </div>
          </div> --}} 
        </div>
      </div>
    </div>
</section>