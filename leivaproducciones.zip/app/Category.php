<?php

namespace leiman;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    //
}
