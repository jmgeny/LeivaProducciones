<?php

namespace leiman;

use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
    //
}
