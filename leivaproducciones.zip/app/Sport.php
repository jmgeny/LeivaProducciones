<?php

namespace leiman;

use Illuminate\Database\Eloquent\Model;

class Sport extends Model
{
    //
}
