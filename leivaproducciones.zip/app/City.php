<?php

namespace leiman;

use Illuminate\Database\Eloquent\Model;

class City extends Model
{
    //
}
