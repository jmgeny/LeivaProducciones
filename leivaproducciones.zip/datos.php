Color logo paratriatlon

Naranja: db9810
Azul: 004e83

