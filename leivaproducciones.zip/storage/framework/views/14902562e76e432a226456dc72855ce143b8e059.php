<?php $__env->startSection('title','Ver Evento'); ?>

<?php $__env->startSection('content'); ?>
	<section class="container-fluid">
		<?php echo $__env->make('navbarAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</section>
	
	<section class="container">
		<section class="row">
			<section class="col-sm-12">
        <h2><?php echo e($evento->nombre); ?></h2>
        <p><?php echo e($evento->fecha); ?> - <?php echo e($evento->city->nombre); ?></p>

<ul class="list-group">
        <li class="list-group-item"><h4>Campeonato:</h4> <?php echo e($evento->championship->nombre); ?></li>
        <li class="list-group-item"><h4>Deporte:</h4> <?php echo e($evento->sport->nombre); ?></li>
        <li class="list-group-item"><h4>Especialidad:</h4> <?php echo e($evento->specification->nombre); ?></li>

        <li class="list-group-item"><h4>Descripción:</h4> <?php echo e($evento->descripcion); ?></li>
        <li class="list-group-item"><h4>Cronograma:</h4> <?php echo e($evento->cronograma); ?></li>
		<li class="list-group-item"><h4>Direccion:</h4> <?php echo e($evento->direccion); ?></li>
		<li class="list-group-item"><h4>Como llegar y donde dormir:</h4> <?php echo e($evento->llegar_dormir); ?></li>

		<li class="list-group-item"><h4>Contacto:</h4> <?php echo e($evento->contacto); ?></li>

        <li class="list-group-item"><h4>Inscriptos:</h4> <?php echo e($evento->inscripto); ?></li>
        <li class="list-group-item"><h4>Resultados:</h4> <?php echo e($evento->resultado); ?></li>
</ul>
		<a href="<?php echo e(route('event.edit', $evento->id)); ?>" class="btn btn-primary">Editar</a>
        <a href="<?php echo e(route('event.index')); ?>" class="btn btn-primary pull-right">Listar</a>
			</section>

		</section>
	</section>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>