            <ul class="list-inline mb-0">
              <li class="list-inline-item">
                <a class="btn btn-outline-light btn-social text-center rounded-circle" target="new" href="https://www.facebook.com/www.leiman">
                  <i class="fa fa-facebook"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a class="btn btn-outline-light btn-social text-center rounded-circle" href="https://www.instagram.com/leimanjorge/?hl=es-la" target="new">
                  <i class="fa fa-instagram"></i>
                </a>
              </li>

            </ul>