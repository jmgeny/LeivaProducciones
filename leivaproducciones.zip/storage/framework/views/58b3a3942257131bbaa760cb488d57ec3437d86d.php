<?php $__env->startSection('title','Campeonatos'); ?>

<?php $__env->startSection('content'); ?>
<section class="container-fluid">
		<?php echo $__env->make('navbarAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</section>
<section class="container">
	<section class="row">
		<section class="col-sm-12">
			<h2>
				Listado de Campeonatos
				<a href="<?php echo e(route('championship.create')); ?>" class="btn btn-primary pull-right">Nuevo</a>
			</h2>
			<?php echo $__env->make('eventos.codigo.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<table class="table">
			<thead>
				<tr>
					<th>Nombre</th>
					<th>Categoria</th>
					<th>Deporte</th>
					<th>Inicio</th>
					<th>Fin</th>
					<th>Ver</th>
					<th>Editar</th>
					<th>Eliminar</th>
					<th>Agregar Evento</th>
				</tr>	
			</thead>
			<tbody>
				<?php $__currentLoopData = $campeonatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campeonato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($campeonato->nombre); ?></td>
					
					<td>Categoria</td>
					
					<td>Deporte</td>
					<td><?php echo e($campeonato->fecha_inicio); ?></td>
					<td><?php echo e($campeonato->fecha_fin); ?></td>
					<td><a href="<?php echo e(route('championship.show', $campeonato->id)); ?>" class="btn btn-primary">ver</a></td>
					<td><a href=" <?php echo e(route('championship.edit', $campeonato->id)); ?>" class="btn btn-primary">Editar</a></td>
					<td><form action="<?php echo e(route('championship.destroy',$campeonato->id)); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

							<input type="hidden" name="_method" value="DELETE">
							<button class="btn btn-danger">Borrar</button>
						</form></td>
					<td><a href="<?php echo e(route('event.create')); ?>" class="btn btn-primary">Evento</a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>				
			</tbody>
		</table>
		
		</section>
	</section>
</section>
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>