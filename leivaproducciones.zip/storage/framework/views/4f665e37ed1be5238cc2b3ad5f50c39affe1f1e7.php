<?php $__env->startSection('title','Leiva Producciones'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Navigation -->
    <?php echo $__env->make('navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Header -->
    <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Eventos Grid Section -->
    

    <!-- Resultados Section -->
    

    <!-- Contact Section -->
    <?php echo $__env->make('contacto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Footer -->
    <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>