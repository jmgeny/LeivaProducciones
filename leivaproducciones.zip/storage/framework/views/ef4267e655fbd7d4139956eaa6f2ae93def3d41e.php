  <div class="form-group">
    <?php echo Form::label('championship_id', 'Campeonato'); ?>

    <?php echo Form::select('championship_id',\leiman\Championship::orderBy('nombre')->pluck('nombre','id'),null,['class' => 'form-control']); ?>

  </div>

  <div class="form-group">
    <?php echo Form::label('nombre', 'Nombre del Evento'); ?>

    <?php echo Form::text('nombre', null, ['class'=> 'form-control']); ?>

  </div>

  <div class="form-group">
    <?php echo Form::label('fecha', 'Fecha'); ?>

    <?php echo Form::date('fecha', null, ['class'=> 'form-control']); ?>

  </div>

  <div class="form-group">
    <?php echo Form::label('ciudad', 'Ciudad'); ?>

    <?php echo Form::select('city_id',\leiman\City::orderBy('nombre')->pluck('nombre','id')
    ,null,['class' => 'form-control']); ?>


  </div>

  <div class="form-group">
    <?php echo Form::label('deporte_id', 'Deporte'); ?>

    <?php echo Form::select('sport_id',\leiman\Sport::orderBy('nombre')->pluck('nombre','id')
    ,null,['class' => 'form-control']); ?>

  </div>

  <div class="form-group">
    <?php echo Form::label('distancia', 'Distancia'); ?>

    <?php echo Form::select('specification_id',\leiman\Specification::orderBy('nombre')->pluck('nombre','id')
    ,null,['class' => 'form-control']); ?>

  </div>

  <div class="form-group">
    <?php echo Form::label('descripcion', 'Descripción'); ?>

    <?php echo Form::textarea('descripcion', null, ['class'=> 'form-control']); ?>

  </div>    

  <div class="form-group">
    <?php echo Form::label('cronograma', 'Cronograma'); ?>

    <?php echo Form::textarea('cronograma', null, ['class'=> 'form-control']); ?>

  </div>

  <div class="form-group">
    <?php echo Form::label('direccion', 'Direccion'); ?>

    <?php echo Form::text('direccion', null, ['class'=> 'form-control']); ?>

  </div>

  <div class="form-group">
    <?php echo Form::label('llegar_dormir', 'Datos de Interes'); ?>

    <?php echo Form::textarea('llegar_dormir', null, ['class'=> 'form-control']); ?>

  </div>

  <div class="form-group">
    <?php echo Form::label('inscripcion', 'Inscripción'); ?>

    <?php echo Form::text('inscripcion', null, ['class'=> 'form-control']); ?>

  </div>

  <div class="form-group">
    <?php echo Form::label('contacto', 'Contacto'); ?>

    <?php echo Form::text('contacto', null, ['class'=> 'form-control']); ?>

  </div>

  <div class="form-group">
    <?php echo Form::label('inscripto', 'Inscriptos'); ?>

    <?php echo Form::file('inscripto'); ?>

  </div>

  <div class="form-group">
    <?php echo Form::label('resultado', 'Resultados'); ?>

    <?php echo Form::file('resultado'); ?>

  </div>  
  
  <div class="form-group">
    <?php echo Form::submit('Enviar',['class' => 'btn btn-primary']); ?>

  </div>    
           
