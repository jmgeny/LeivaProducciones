<?php $__env->startSection('title','Todos los Eventos'); ?>

<?php $__env->startSection('content'); ?>
<section class="container-fluid">
		<?php echo $__env->make('navbarAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</section>
<section class="container">
	<section class="row">
		<section class="col-sm-12">
		<h2>
			Listado de Evento
			<a href="<?php echo e(route('event.create')); ?>" class="btn btn-primary pull-right">Nuevo</a>
		</h2>
			<?php echo $__env->make('eventos.codigo.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<table class="table">
			<thead>
				<tr>
					<th>Campeonato</th>
					<th>Nombre</th>
					<th>Fecha</th>
					<th>Ciudad</th>
					<th>Deporte</th>
					<th>ver</th>
					<th>Editar</th>
					<th>Eliminar</th>
				</tr>	
			</thead>
			<tbody>
				<?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($evento->championship->nombre); ?></td>
					<td><?php echo e($evento->nombre); ?></td>
					<td><?php echo e($evento->fecha); ?></td>
					<td><?php echo e($evento->city->nombre); ?></td>
					<td><?php echo e($evento->sport->nombre); ?></td>
					<td><a href="<?php echo e(route('event.show', $evento->id)); ?>" class="btn btn-primary">ver</a></td>
					<td><a href=" <?php echo e(route('event.edit', $evento->id)); ?>" class="btn btn-primary">Editar</a></td>
					<td><form action="<?php echo e(route('event.destroy',$evento->id)); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

							<input type="hidden" name="_method" value="DELETE">
							<button class="btn btn-danger">Borrar</button>
						</form></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>				
			</tbody>
		</table>
		</section>
	</section>
</section>
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>