  <div class="form-group">
    <?php echo Form::label('nombre', 'Nombre del Evento'); ?>

    <?php echo Form::text('nombre', null, ['class'=> 'form-control']); ?>

  </div>

  <div class="form-group">
    <?php echo Form::label('fecha_inicio', 'Fecha de Inicio'); ?>

    <?php echo Form::date('fecha_inicio', null, ['class'=> 'form-control']); ?>

  </div>

  <div class="form-group">
    <?php echo Form::label('fecha_fin', 'Fecha de Fin'); ?>

    <?php echo Form::date('fecha_fin', null, ['class'=> 'form-control']); ?>

  </div>

  <div class="form-group">
    <?php echo Form::label('categoria','Categoria'); ?>

    <?php echo Form::select('category_id', \leiman\Category::orderBy('nombre')->pluck('nombre','id') ,null,['class' => 'form-control']); ?>

  </div>

  <div class="form-group">
    <?php echo Form::label('deporte','Deporte'); ?>

    <?php echo Form::select('sport_id', \leiman\Sport::orderBy('nombre')->pluck('nombre', 'id') ,null,['class' => 'form-control']); ?>

  </div>

  <div class="form-group">
    <?php echo Form::label('avatar','Imagen'); ?>

    <?php echo Form::file('avatar'); ?>

  </div>

  <div class="form-group">
    <?php echo Form::submit('Enviar',['class' => 'btn btn-primary']); ?>

  </div>    