    <section class="evento bg-primary" id="resultado">
      <div class="container">
        <a href="<?php echo e(url('/allResultados')); ?>"><h2 class="text-center text-uppercase text-secondary mb-4">Resultados</h2></a>
        <div class="row">
            <?php $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-6 col-lg-4">
            <a class="evento-item d-block" href="<?php echo e(url('/evento',$resultado->id)); ?>">
              
               <div class="card text-center">
                  <div class="card-title">
                    <p class="card-text"><?php echo e($resultado->nombre); ?></p>
                    <p class="card-text"><?php echo e($resultado->city->nombre); ?> - <?php echo e($resultado->fecha); ?></p>
                  </div>
                <div class="card-body">
                  <img class="card-img-top" src="<?php echo e(Storage::url($resultado->championship->avatar)); ?>" alt="img">
                </div>
              </div>

            </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>