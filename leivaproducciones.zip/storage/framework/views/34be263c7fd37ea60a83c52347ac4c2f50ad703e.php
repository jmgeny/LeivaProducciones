    <section class="evento" id="evento">
      <div class="container">
        <a href="<?php echo e(url('/allEventos')); ?>"><h2 class="text-center text-uppercase text-secondary mb-4">Próximos Eventos</h2></a>
        <div class="row">
            <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-6 col-lg-4">
            <a class="evento-item d-block" href="<?php echo e(url('/evento',$evento->id)); ?>">
              
               <div class="card text-center">
                  <div class="card-title">
                    <p class="card-text"><?php echo e($evento->nombre); ?></p>
                    <p class="card-text"><?php echo e($evento->city->nombre); ?> - <?php echo e($evento->fecha); ?></p>
                  </div>
                <div class="card-body">
                  <img class="card-img-top" src="<?php echo e(Storage::url($evento->championship->avatar)); ?>" alt="img">
                </div>
              </div>

            </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>