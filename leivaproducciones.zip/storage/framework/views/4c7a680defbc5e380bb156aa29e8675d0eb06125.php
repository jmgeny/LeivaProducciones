<?php $__env->startSection('title','Ver Campeonato'); ?>

<?php $__env->startSection('content'); ?>
	<section class="container-fluid">
		<?php echo $__env->make('navbarAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</section>
	
	<section class="container">
		<section class="row">
			<section class="col-sm-10">
		    <h2>
		      Ver Campeonato
		      <a href="<?php echo e(route('championship.index')); ?>" class="btn btn-primary pull-right">Listar</a>
		    </h2>

			<div class="panel panel-default">
				<div class="panel-heading">
				  	<p><?php echo e($campeonato->nombre); ?></p>
				  	<p><?php echo e($campeonato->fecha_inicio); ?> hasta <?php echo e($campeonato->fecha_fin); ?></p>
				</div>
				<div class="panel-body">
				  	<img src="#" class="img-rounded" alt="Cinque Terre">
				  	<p>Categoria: <?php echo e($campeonato->category_id); ?></p>
				  	<p>Deporte: <?php echo e($campeonato->sport_id); ?></p>
				</div>
				<div class="panel-footer">
				  	<a href=" <?php echo e(route('championship.edit', $campeonato->id)); ?>" class="btn btn-primary">Editar</a>
				</div>				
			</div>
        	</section>
			<section class="col-sm-2">
				
			</section>
		</section>
	</section>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>