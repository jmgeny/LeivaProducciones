    <footer class="footer text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-4 mb-5 mb-lg-0">
            
          </div>
          <div class="col-md-4 mb-5 mb-lg-0">
            <?php echo $__env->make('redes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </div>
          <div class="col-md-4">
            
          </div>
        </div>
      </div>
    </footer>