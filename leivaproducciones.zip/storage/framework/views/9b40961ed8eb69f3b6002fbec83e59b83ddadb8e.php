<?php $__env->startSection('title','Resultado'); ?>

<?php $__env->startSection('content'); ?>
<section class="container-fluid">
		<?php echo $__env->make('navbar2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</section>

<section class="container">
	<h2>Todos los Resultados</h2>
<section class="row">
	<article class="col-sm-8">
		
            <?php $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-6 col-lg-4 divEvento">
            <a class="evento-item d-block mx-auto" href="<?php echo e(url('/evento',$resultado->id)); ?>">
              <div class="card">
                <img class="card-img-top" src="<?php echo e(Storage::url($resultado->championship->avatar)); ?>" alt="Card image">
                <div class="card-body">
                  <h4 class="card-title"><?php echo e($resultado->nombre); ?></h4>
                  <p class="card-text"><?php echo e($resultado->city->nombre); ?> - <?php echo e($resultado->fecha); ?></p>
                </div>
              </div>
            </a>
          </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
	</article>

	<aside class="col-sm-4">
		<?php echo $__env->make('aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</aside>

</section>	
</section> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>