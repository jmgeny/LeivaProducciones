<?php $__env->startSection('title','Editar Campeonato'); ?>

<?php $__env->startSection('content'); ?>
<section class="container-fluid">
		<?php echo $__env->make('navbarAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</section>
<section class="container">
	<section class="row">
		<section class="col-sm-12">
		    <h2>
		      Editar Campeonato
		      <a href="<?php echo e(route('championship.index')); ?>" class="btn btn-primary pull-right">Listar</a>
		    </h2>
		    <?php echo $__env->make('extras.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		    <?php echo $__env->make('eventos.codigo.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		    <?php echo Form::model($campeonato, ['route' => ['championship.update', $campeonato->id], 'method' =>'PUT', 'files' => true]); ?>

		      <?php echo $__env->make('campeonatos.codigo.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		    <?php echo Form::close(); ?>


		</section>

	</section>
</section>
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>