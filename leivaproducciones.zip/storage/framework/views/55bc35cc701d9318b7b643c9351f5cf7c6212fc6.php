<?php $__env->startSection('title','Evento'); ?>

<?php $__env->startSection('content'); ?>
<section class="container-fluid">
		<?php echo $__env->make('navbar2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</section>

<section class="container">
  <h1>Evento</h1>
  <section class="row">
    <section class="col-sm-8">
      <div>
        <h2><?php echo e($evento->championship->nombre); ?></h2>
      </div>  
      <div class="row">
        <div class="col-md-4">
          <img class="img-fluid rounded mb-3 mb-md-0" src="<?php echo e(Storage::url($evento->championship->avatar)); ?>" alt="">
        </div>
        <div class="col-md-8">
          <h2><?php echo e($evento->nombre); ?></h2>
          <h3><?php echo e($evento->fecha); ?> - <?php echo e($evento->city->nombre); ?></h3>
          <div class="row">
            <div class="col-md-6">
              <?php if($evento->inscripto): ?>
              <a href="<?php echo e(Storage::url($evento->inscripto)); ?>"><button class="btn btn-primary"><h3>Inscriptos</h3></button></a>
              <?php endif; ?>
            </div>
            <div class="col-md-6">
              <a href="<?php echo e(Storage::url($evento->resultado)); ?>"><button class="btn btn-primary"><h3>Reultado</h3></button></a>
            </div>
          </div>
          <p><h4>Deporte: </h4><?php echo e($evento->sport->nombre); ?></p>
          <p><h4>Distancia:</h4> <?php echo e($evento->specification->nombre); ?></p>
          <p><h4>Descrición:</h4> <?php echo e($evento->descripcion); ?></p>
          <p><h4>Cronogram</h4> <?php echo e($evento->cronograma); ?></p>
          <p><h4>Dierección:</h4> <?php echo e($evento->direccion); ?></p>
          <p><h4>Mas datos:</h4> <?php echo e($evento->llegar_dormir); ?></p>
          <p><h4>Contacto:</h4> <?php echo e($evento->inscripcion); ?></p>
        </div>
      </div>
    </section>
    <aside class="col-sm-4">
      <?php echo $__env->make('aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </aside>
  </section>	
</section> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vistas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>